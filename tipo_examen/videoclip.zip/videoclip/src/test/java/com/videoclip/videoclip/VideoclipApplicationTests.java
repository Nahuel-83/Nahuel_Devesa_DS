package com.videoclip.videoclip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideoclipApplicationTests {

	@Test
	void contextLoads() {
	}

}
