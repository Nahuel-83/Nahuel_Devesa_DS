package com.videoclip.videoclip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideoclipApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideoclipApplication.class, args);
	}

}
