package com.vacafactory.vacas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VacasApplication {

	public static void main(String[] args) {
		SpringApplication.run(VacasApplication.class, args);
	}

}
