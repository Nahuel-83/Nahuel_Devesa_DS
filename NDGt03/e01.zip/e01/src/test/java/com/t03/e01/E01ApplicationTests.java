package com.t03.e01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
