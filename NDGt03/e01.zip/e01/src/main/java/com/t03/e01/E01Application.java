package com.t03.e01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E01Application {

	public static void main(String[] args) {
		SpringApplication.run(E01Application.class, args);
	}

}
