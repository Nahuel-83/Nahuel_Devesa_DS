package com.nldg.nldg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NldgApplication {

	public static void main(String[] args) {
		SpringApplication.run(NldgApplication.class, args);
	}

}
